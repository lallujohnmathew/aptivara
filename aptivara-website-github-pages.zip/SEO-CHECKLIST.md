# APTIVARA SEO checklist
## Phase 1 - Technical (first)
- [ ] Upload site; test all menu links (desktop + mobile); open /sitemap.xml and /robots.txt
- [ ] Test a made-up URL (e.g. /test123) shows the branded 404 page
- [ ] Search Console: add property, submit sitemap, Request indexing for the key pages
- [ ] Confirm https + www is the only version that loads
## Phase 2 - Content
- [ ] Read all copy; add your own expertise, course details and examples (no invented clients/stats)
- [ ] When real online courses launch, add a page per course and add it to sitemap.xml
## Phase 3 - Authority
LinkedIn post -> Insights article -> Intellectual Learning Framework -> Online Courses / Corporate Learning -> Contact
## Phase 4 - Growth
- [ ] Keyword research; industry pages; new articles; internal links; backlinks; GBP if eligible; conversion tracking
