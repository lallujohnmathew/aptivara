(function(){
var FORM_ENDPOINT="";/* paste your Formspree/Getform endpoint here to send enquiries directly; leave empty to open the visitor's email app */
var GA_ID="";/* paste GA4 Measurement ID (G-XXXXXXX) to enable analytics */
if(GA_ID){var s=document.createElement("script");s.async=1;s.src="https://www.googletagmanager.com/gtag/js?id="+GA_ID;document.head.appendChild(s);window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments)};gtag("js",new Date());gtag("config",GA_ID)}
var b=document.querySelector(".mt"),m=document.getElementById("mn");
if(b&&m)b.addEventListener("click",function(){var o=m.classList.toggle("open");b.setAttribute("aria-expanded",o)});
var p=location.pathname;document.querySelectorAll(".ap-n li a").forEach(function(a){var h=a.getAttribute("href");if(h===p||(h!=="/"&&p.indexOf(h)===0))a.setAttribute("aria-current","page")});
var qi=new URLSearchParams(location.search).get("interest");document.querySelectorAll("form.cf").forEach(function(f){if(qi&&f.elements.interest)f.elements.interest.value=qi;
var st=document.createElement("p");st.className="st";st.setAttribute("role","status");st.setAttribute("aria-live","polite");f.appendChild(st);
var hp=document.createElement("input");hp.name="_gotcha";hp.tabIndex=-1;hp.autocomplete="off";hp.className="fs";hp.setAttribute("aria-hidden","true");f.appendChild(hp);
f.addEventListener("submit",function(e){e.preventDefault();if(hp.value)return;
var g=function(n){return f.elements[n].value};
if(FORM_ENDPOINT){var btn=f.querySelector("button");btn.disabled=true;st.textContent="Sending…";
fetch(FORM_ENDPOINT,{method:"POST",body:new FormData(f),headers:{Accept:"application/json"}}).then(function(r){if(r.ok){f.reset();st.textContent="Thank you. Your message has been sent and we will be in touch.";if(window.gtag)gtag("event","generate_lead")}else throw 0}).catch(function(){st.textContent="Sorry, something went wrong. Please email aptivaralearning@gmail.com.";}).finally(function(){btn.disabled=false});return}
var body="Name: "+g("name")+"\nEmail: "+g("email")+"\nOrganization: "+g("org")+"\nJob Title: "+g("title")+"\nArea of Interest: "+g("interest")+"\n\n"+g("msg");
location.href="mailto:aptivaralearning@gmail.com?subject="+encodeURIComponent("Enquiry: "+g("interest"))+"&body="+encodeURIComponent(body)})})})();