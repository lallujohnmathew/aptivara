APTIVARA - GITHUB PAGES PACKAGE (www.aptivaralearning.com)
1. Create a GitHub repository, upload ALL files from this folder to the root of the repo (including CNAME and .nojekyll).
2. Settings > Pages > Source: "Deploy from a branch" > main / (root).
3. Settings > Pages > Custom domain: www.aptivaralearning.com > Save. Tick "Enforce HTTPS" when available.
4. At your domain registrar's DNS: CNAME  www -> YOUR-GITHUB-USERNAME.github.io  (no repo name).
   Optional apex (aptivaralearning.com) A records: 185.199.108.153 / .109.153 / .110.153 / .111.153
5. Wait for DNS (up to 24h), then test every menu link and a made-up URL (/test123 shows 404.html).
6. Search Console: submit https://www.aptivaralearning.com/sitemap.xml
Note: GitHub Pages ignores .htaccess/_redirects; old URLs are handled by small redirect pages (about-us, blog, services...).
Contact: aptivaralearning@gmail.com | LinkedIn: https://www.linkedin.com/company/aptivara/
